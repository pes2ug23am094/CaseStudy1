#ifndef HEADER_H
#define HEADER_H
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[50];
    float price;
    int quantity;
} Product;

typedef struct {
    char first_name[50];
    char last_name[50];
    int id;
    float total_amount;
} Customer;

// Function prototypes
void addCustomer(Customer *customers, int *num_customers);
void modifyCustomer(Customer *customers, int num_customers);
void generateBill(Customer *customers, int num_customers, Product *products, int num_products);
void displayCustomers(Customer *customers, int num_customers);
void viewProductStock(Product *products, int num_products);
void applyDiscount(float *total_bill);
void viewProductDetails(Product *products, int num_products);

#endif
